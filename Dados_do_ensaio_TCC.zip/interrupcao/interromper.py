"""Experimento pareado de transferência integral ou truncada em servidor local."""
import argparse
import csv
import hashlib
import importlib.util
import json
import secrets
import socket
import struct
import threading
import time
import zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

CORTE = 65536
ESPERA = 5

def criar_png():
    """PNG RGB de 256 x 256; pixels sintéticos e reprodutíveis."""
    def bloco(tipo, dados):
        return struct.pack(">I", len(dados)) + tipo + dados + struct.pack(">I", zlib.crc32(tipo + dados))
    linhas = []
    for y in range(256):
        pixels = b"".join(hashlib.sha256(struct.pack(">II", y, i)).digest() for i in range(24))
        linhas.append(b"\0" + pixels)
    header = struct.pack(">IIBBBBB", 256, 256, 8, 2, 0, 0, 0)
    return b"\x89PNG\r\n\x1a\n" + bloco(b"IHDR", header) + bloco(b"IDAT", zlib.compress(b"".join(linhas))) + bloco(b"IEND", b"")

class Servidor(BaseHTTPRequestHandler):
    def do_GET(self):
        estudo = self.server
        if self.path == "/pagina":
            corpo = b'<a href="/figura.png" download="figura.png">Baixar</a>'
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.send_header("Content-Length", str(len(corpo)))
            self.end_headers()
            self.wfile.write(corpo)
            return
        if self.path != "/figura.png":
            self.send_error(404)
            return
        corpo = estudo.png if estudo.condicao == "integral" else estudo.png[:CORTE]
        self.send_response(200)
        self.send_header("Content-Length", str(len(estudo.png)))
        self.send_header("Content-Type", "image/png")
        self.send_header("Cache-Control", "public, max-age=3600")
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(corpo)
        self.wfile.flush()
        estudo.eventos.append(dict(bytes_enviados=len(corpo), range_solicitado=self.headers.get("Range")))
        self.close_connection = True
        self.connection.shutdown(socket.SHUT_WR)
        estudo.pronto.set()

    def log_message(self, *args):
        pass

def rodar(pasta, engine, repeticoes, coletor):
    spec = importlib.util.spec_from_file_location("coletor_anterior", coletor)
    drivers = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(drivers)
    pasta.mkdir(parents=True, exist_ok=False)
    png = criar_png()
    (pasta / "referencia.png").write_bytes(png)
    with (pasta / "sessoes.csv").open("w", newline="") as destino:
        escritor = csv.writer(destino)
        escritor.writerow(["codigo", "ambiente", "versao", "bloco", "ordem", "condicao", "requisicoes", "bytes_por_resposta"])
        for bloco in range(1, repeticoes + 1):
            ordem = ["integral", "truncada"] if bloco % 2 else ["truncada", "integral"]
            for pos, condicao in enumerate(ordem, 1):
                codigo = secrets.token_hex(6)
                caso = pasta / "casos" / codigo
                perfil, arquivos = caso / "perfil", caso / "destino"
                perfil.mkdir(parents=True)
                arquivos.mkdir()
                with ThreadingHTTPServer(("127.0.0.1", 0), Servidor) as servidor:
                    servidor.png = png
                    servidor.condicao = condicao
                    servidor.eventos = []
                    servidor.pronto = threading.Event()
                    threading.Thread(target=servidor.serve_forever, daemon=True).start()
                    def aguardar_resposta(_destino):
                        if not servidor.pronto.wait(15):
                            raise RuntimeError("A resposta ao download não terminou no servidor.")
                        time.sleep(ESPERA)
                    drivers.aguardar_arquivo = aguardar_resposta
                    try:
                        versao = getattr(drivers, engine)(perfil, arquivos, f"http://127.0.0.1:{servidor.server_port}/pagina", "D")
                    finally:
                        servidor.shutdown()
                (caso / "servidor.json").write_text(json.dumps(servidor.eventos))
                tamanhos = [x["bytes_enviados"] for x in servidor.eventos]
                assert tamanhos and all(n == (len(png) if condicao == "integral" else CORTE) for n in tamanhos)
                escritor.writerow([codigo, engine, versao, bloco, pos, condicao, len(tamanhos), "|".join(map(str,tamanhos))])
                destino.flush()
                print(engine, bloco, pos, condicao, flush=True)

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("ambiente", choices=["firefox", "chromium"])
    p.add_argument("saida", type=Path)
    p.add_argument("--blocos", type=int, default=4)
    p.add_argument("--coletor", type=Path, default=Path(__file__).resolve().parent.parent / "pos_fechamento" / "coletar.py")
    args = p.parse_args()
    rodar(args.saida.resolve(), args.ambiente, args.blocos, args.coletor)
