"""Exame dos diretórios de destino e do histórico após a saída do navegador."""
import argparse
import csv
import hashlib
import json
import sqlite3
from pathlib import Path

def examinar(caso, referencia):
    arquivos = []
    for arquivo in sorted((caso / "destino").rglob("*")):
        if not arquivo.is_file():
            continue
        dados = arquivo.read_bytes()
        if dados == referencia:
            classe = "integral"
        elif dados and len(dados) < len(referencia) and referencia.startswith(dados):
            classe = "prefixo"
        elif not dados:
            classe = "vazio"
        else:
            classe = "outro"
        arquivos.append(dict(nome=arquivo.name, bytes=len(dados), classe=classe, sha256=hashlib.sha256(dados).hexdigest()))
    db = caso / "perfil" / "places.sqlite"
    anotacoes = {}
    if db.is_file():
        wal = db.with_name("places.sqlite-wal")
        if wal.exists() and wal.stat().st_size:
            raise RuntimeError("O banco contém WAL não consolidado.")
        query = """SELECT a.name, n.content FROM moz_annos n
                   JOIN moz_anno_attributes a ON a.id = n.anno_attribute_id
                   JOIN moz_places p ON p.id = n.place_id
                   WHERE p.url LIKE 'http://127.0.0.1:%/figura.png'"""
        with sqlite3.connect(db.resolve().as_uri()+"?mode=ro&immutable=1", uri=True) as con:
            anotacoes = dict(con.execute(query))
    estado = json.loads(anotacoes.get("downloads/metaData","{}")).get("state")
    return dict(codigo=caso.name, arquivos=json.dumps(arquivos, ensure_ascii=False, sort_keys=True), integral=int(any(f["classe"]=="integral" for f in arquivos)), prefixo=int(any(f["classe"]=="prefixo" for f in arquivos)), vazio=int(any(f["classe"]=="vazio" for f in arquivos)), destino_anotado=int("downloads/destinationFileURI" in anotacoes) if db.exists() else "NA", estado=estado if estado is not None else "NA", history=int((caso/"perfil"/"Default"/"History").is_file()))

def medir(raiz, saida):
    resultado = []
    for engine in ("firefox","chromium"):
        grupo = raiz / engine
        referencia = (grupo / "referencia.png").read_bytes()
        achados = {c.name:examinar(c,referencia) for c in sorted((grupo/"casos").iterdir())}
        with (grupo/"sessoes.csv").open() as f:
            for linha in csv.DictReader(f):
                resultado.append({**linha, **achados.pop(linha["codigo"])})
        assert not achados
    with saida.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=resultado[0].keys())
        w.writeheader()
        w.writerows(resultado)

if __name__ == "__main__":
    p=argparse.ArgumentParser()
    p.add_argument("raiz", type=Path)
    p.add_argument("saida", type=Path)
    a=p.parse_args()
    medir(a.raiz,a.saida)
