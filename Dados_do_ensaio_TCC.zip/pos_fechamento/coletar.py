"""Ensaio com recurso local inofensivo; diretórios novos para cada sessão."""
import csv, json, os, secrets, socket, subprocess, sys, threading, time
from pathlib import Path
from urllib.request import build_opener, ProxyHandler, Request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from playwright.sync_api import sync_playwright
from contextlib import contextmanager
BASE=Path(__file__).resolve().parent
PNG=(BASE/'figura.png').read_bytes()
HTML={'C':'<p>Controle</p>','L':'<a href="/figura.png">Figura</a>','I':'<img src="/figura.png">','D':'<a href="/figura.png" download="figura.png">Baixar</a>'}
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.server.log.append(self.path)
        if self.path=='/pagina':data=HTML[self.server.caso].encode();tipo='text/html';cache='no-store'
        elif self.path=='/figura.png':data=PNG;tipo='image/png';cache='public, max-age=3600'
        else:self.send_error(404);return
        self.send_response(200)
        for k,v in [('Content-Type',tipo),('Content-Length',str(len(data))),('Cache-Control',cache)]:self.send_header(k,v)
        self.end_headers();self.wfile.write(data)
    def log_message(self,*args): pass
def aguardar_arquivo(dest):
    for _ in range(120):
        p=dest/'figura.png'
        if p.exists() and p.read_bytes()==PNG:return
        time.sleep(.1)
    raise RuntimeError('O destino nativo não recebeu o objeto.')
def firefox(profile,dest,url,case):
    with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
    proc=subprocess.Popen([os.environ['GECKODRIVER'],'--port',str(port)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    client=build_opener(ProxyHandler({}))
    def req(method,path,data=None):
        r=Request(f'http://127.0.0.1:{port}'+path,method=method,data=json.dumps(data).encode() if data is not None else None,headers={'Content-Type':'application/json'})
        return json.load(client.open(r,timeout=35))['value']
    sid=None
    try:
        for _ in range(80):
            try:req('GET','/status');break
            except OSError:time.sleep(.1)
        prefs={'browser.download.folderList':2,'browser.download.dir':str(dest),'browser.download.useDownloadDir':True,'browser.helperApps.neverAsk.saveToDisk':'image/png','browser.cache.disk.enable':True,'browser.privatebrowsing.autostart':False}
        caps=req('POST','/session',{'capabilities':{'alwaysMatch':{'browserName':'firefox','moz:firefoxOptions':{'binary':os.environ['FIREFOX'],'args':['-headless','-profile',str(profile)],'prefs':prefs}}}})
        sid='/session/'+caps['sessionId'];ver=caps['capabilities']['browserVersion']
        req('POST',sid+'/url',{'url':url})
        if case=='I':assert req('POST',sid+'/execute/sync',{'script':'return document.images[0].complete && document.images[0].naturalWidth===64','args':[]})
        if case=='D':
            elem=req('POST',sid+'/element',{'using':'css selector','value':'a'})
            req('POST',sid+'/element/'+next(iter(elem.values()))+'/click',{})
            aguardar_arquivo(dest)
        time.sleep(1.5)
        return ver
    finally:
        try:
            if sid:req('DELETE',sid)
        finally:proc.terminate();proc.wait(timeout=10)
def chromium(profile,dest,url,case):
    with sync_playwright() as pw:
        ctx=pw.chromium.launch_persistent_context(str(profile),executable_path=os.environ['CHROMIUM'],headless=True)
        try:
            p=ctx.pages[0];cdp=ctx.new_cdp_session(p)
            cdp.send('Browser.setDownloadBehavior',{'behavior':'allow','downloadPath':str(dest)})
            p.goto(url,wait_until='load')
            if case=='I':assert p.locator('img').evaluate('(e)=>e.complete && e.naturalWidth===64')
            if case=='D':p.locator('a').click();aguardar_arquivo(dest)
            time.sleep(1.5)
            return ctx.browser.version
        finally:ctx.close()
def executar(engine,out,sequences):
    root=out/'casos';root.mkdir(parents=True,exist_ok=False)
    srv=ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=srv.serve_forever,daemon=True).start()
    url=f'http://127.0.0.1:{srv.server_port}/pagina'
    with (out/'gabarito.csv').open('w') as f:
        w=csv.writer(f);w.writerow(['codigo','navegador','versao','bloco','ordem','condicao','get_figura'])
        for bloco,seq in enumerate(sequences,1):
            for ordem,case in enumerate(seq,1):
                code=secrets.token_hex(8);d=root/code;profile=d/'perfil';dest=d/'destino';profile.mkdir(parents=True);dest.mkdir()
                srv.caso=case;srv.log=[]
                ver={'firefox':firefox,'chromium':chromium}[engine](profile,dest,url,case)
                w.writerow([code,engine,ver,bloco,ordem,case,srv.log.count('/figura.png')]);f.flush()
                print(engine,bloco,ordem,flush=True)
    srv.shutdown()
if __name__=='__main__':executar(sys.argv[1],Path(sys.argv[2]).resolve(),sys.argv[3:] or ['CLID','LIDC','IDCL','DCLI'])
