import csv,sqlite3,collections,sys
from pathlib import Path
def rows(p):
 with p.open() as f:return list(csv.DictReader(f))
def conferir(base):
 out=[]
 for s in ['serie_chr','serie_ff']:
  path=base/s; preds={r['codigo']:r for r in rows(path/'previsoes.csv')}
  for truth in rows(path/'gabarito.csv'):
   k=truth['codigo'];case=path/'casos'/k/'perfil';dbs=list(case.rglob('places.sqlite'));matches=[]
   for p in dbs:
    wal=Path(str(p)+'-wal')
    assert not wal.exists() or wal.stat().st_size==0
    with sqlite3.connect(p.resolve().as_uri()+'?mode=ro&immutable=1',uri=True) as d:
     matches+=list(d.execute("select a.name from moz_annos n join moz_anno_attributes a on a.id=n.anno_attribute_id join moz_places p on p.id=n.place_id where p.url like 'http://127.0.0.1:%/figura.png'"))
   row={**truth,**preds[k],'anotacao_destino':int(('downloads/destinationFileURI',) in matches) if dbs else 'NA','anotacao_metadados':int(('downloads/metaData',) in matches) if dbs else 'NA','arquivo_History':int((case/'Default'/'History').exists())}
   out.append(row)
 with (base/'resultados.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=out[0]);w.writeheader();w.writerows(out)
 for p in ('firefox','chromium'):
  for c in 'CLID':
   r=[a for a in out if a['navegador']==p and a['condicao']==c]
   print(p,c,len(r),{key:sorted(set(str(a[key]) for a in r)) for key in ('get_figura','diretorios_cache','png_integral_cache','arquivo_igual_destino','previsao','anotacao_destino','anotacao_metadados','arquivo_History')})
if __name__=='__main__':conferir(Path(sys.argv[1]))
