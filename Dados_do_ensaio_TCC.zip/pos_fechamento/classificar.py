"""Leitura pós-fechamento. A única entrada sobre o objeto é a figura de referência."""
import csv, hashlib, sys
from pathlib import Path

def analisar(raiz, figura, saida):
    alvo=figura.read_bytes()
    rows=[]
    for caso in sorted(raiz.iterdir()):
        if not caso.is_dir(): continue
        destino=any(f.read_bytes()==alvo for f in (caso/'destino').rglob('*') if f.is_file())
        pastas=[p for p in (caso/'perfil').rglob('*') if p.is_dir() and (p.name=='Cache_Data' or (p.name=='entries' and p.parent.name=='cache2'))]
        cache=any(alvo in f.read_bytes() for p in pastas for f in p.rglob('*') if f.is_file())
        rotulo='D' if destino else 'I' if cache else '?'
        rows.append([caso.name,int(destino),int(cache),len(pastas),rotulo])
    with saida.open('w') as f:
        w=csv.writer(f);w.writerow(['codigo','arquivo_igual_destino','png_integral_cache','diretorios_cache','previsao']);w.writerows(rows)
if __name__=='__main__':analisar(*map(Path,sys.argv[1:]))
