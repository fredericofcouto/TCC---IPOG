from pathlib import Path
import csv, hashlib, io, json, sqlite3, threading, platform, sys
from collections import Counter
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from playwright.sync_api import sync_playwright
from PIL import Image, ImageDraw
from importlib.metadata import version as pkgversion

out = Path(sys.argv[1]).resolve()
out.mkdir(parents=True, exist_ok=False)
src=Image.new('RGB',(64,64),'white');ImageDraw.Draw(src).rectangle((8,8,55,55),fill=(35,116,165))
b=io.BytesIO();src.save(b,format='PNG');png=b.getvalue()
sha=hashlib.sha256(png).hexdigest()
(out/'figura.png').write_bytes(png)
cases={'C':'<p>Controle</p>', 'L':'<a href="/figura.png">Figura</a>', 'I':'<img src="/figura.png" alt="Quadrado">', 'D':'<a href="/figura.png" download="figura.png">Baixar</a>'}
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.server.requests.append(self.path)
        if self.path=='/pagina': data,mime,cache=cases[self.server.case].encode(),'text/html','no-store'
        elif self.path=='/figura.png': data,mime,cache=png,'image/png','public, max-age=3600'
        else: self.send_error(404); return
        self.send_response(200)
        for k,v in [('Content-Type',mime),('Content-Length',str(len(data))),('Cache-Control',cache)]: self.send_header(k,v)
        self.end_headers();self.wfile.write(data)
    def log_message(self,*a):pass
server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
threading.Thread(target=server.serve_forever,daemon=True).start()
origin=f'http://127.0.0.1:{server.server_port}'
rows=[]
with sync_playwright() as pw:
 for rep,sequence in enumerate(['CLID','LIDC','IDCL','DCLI'],1):
  for pos,case in enumerate(sequence,1):
   run=out/f'{rep}-{pos}-{case}';profile=run/'perfil'
   server.case=case;server.requests=[]
   ctx=pw.firefox.launch_persistent_context(str(profile),headless=True,accept_downloads=True,firefox_user_prefs={'browser.cache.disk.enable':True,'browser.privatebrowsing.autostart':False,'browser.cache.disk.parent_directory':str(run/'cache')})
   version=ctx.browser.version
   p=ctx.pages[0]
   events=[];p.on('download',lambda d:events.append(d.suggested_filename))
   p.goto(origin+'/pagina',wait_until='networkidle')
   if case=='I':assert p.locator('img').evaluate('(e)=>e.complete && e.naturalWidth===64')
   dest=run/'recebido.png'
   if case=='D':
    with p.expect_download() as ev:p.get_by_text('Baixar').click()
    assert ev.value.failure() is None
    ev.value.save_as(dest)
   p.wait_for_timeout(1200);ctx.close()
   with sqlite3.connect((profile/'places.sqlite').as_uri()+'?mode=ro',uri=True) as db:
    def hist(path):
     return list(db.execute('select v.visit_type from moz_historyvisits v join moz_places p on p.id=v.place_id where p.url=?',(origin+path,)))
    pagevis=hist('/pagina');targetvis=hist('/figura.png')
   cachedirs=list(run.rglob('cache2/entries'))
   cachehits=sum(png in f.read_bytes() for cd in cachedirs for f in cd.iterdir() if f.is_file())
   rows.append(dict(bloco=rep,ordem=pos,cenario=case,get=server.requests.count('/figura.png'),visitas_pagina=len(pagevis),tipos_visita_figura=','.join(str(a) for a, in targetvis),cache_dirs=len(cachedirs),cache_hits=cachehits,eventos=len(events),copia=int(dest.exists() and hashlib.sha256(dest.read_bytes()).hexdigest()==sha)))
   print(rows[-1],flush=True)
   (run/'observacao.json').write_text(json.dumps({'http':server.requests,'eventos':events,'visitas_pagina':pagevis,'visitas_figura':targetvis,'cache_dirs':[str(d.relative_to(run)) for d in cachedirs],'linha':rows[-1]}))
server.shutdown()
with (out/'resultados.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
(out/'ambiente.json').write_text(json.dumps(dict(firefox=version,playwright=pkgversion('playwright'),plataforma=platform.platform(),bytes_png=len(png),sha256=sha),indent=2))
